<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>重置密码 - IPTV代理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f8fa;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .reset-container {
            max-width: 440px;
            width: 100%;
            padding: 20px;
        }
        .reset-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .reset-logo i {
            font-size: 48px;
            color: #3B82F6;
        }
        .card {
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 24px;
        }
        .step-indicator .step {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #e9ecef;
            color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        .step-indicator .step.active {
            background: #3B82F6;
            color: #fff;
        }
        .step-indicator .step.completed {
            background: #10B981;
            color: #fff;
        }
        .step-indicator .step-line {
            width: 48px;
            height: 2px;
            background: #e9ecef;
            align-self: center;
            margin: 0 4px;
            transition: all 0.3s;
        }
        .step-indicator .step-line.active {
            background: #3B82F6;
        }
        .step-panel {
            display: none;
        }
        .step-panel.active {
            display: block;
        }
        .security-hint {
            background: #fff8e1;
            border: 1px solid #ffc107;
            border-radius: 6px;
            padding: 12px 16px;
            margin-bottom: 16px;
            font-size: 13px;
            color: #795548;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <div class="reset-logo">
            <i class="bi bi-shield-lock"></i>
            <h3 class="mt-3">重置管理员密码</h3>
            <p class="text-muted small">广播电视网络监控系统 v3.2</p>
        </div>

        <div class="step-indicator">
            <div class="step active" id="stepDot1">1</div>
            <div class="step-line" id="stepLine"></div>
            <div class="step" id="stepDot2">2</div>
        </div>

        <div class="card">
            <div class="card-body p-4">

                <div id="alertContainer"></div>

                <!-- Step 1: 输入用户名 -->
                <div class="step-panel active" id="step1Panel">
                    <h5 class="card-title mb-3">验证身份</h5>
                    <p class="text-muted small mb-4">请输入您的管理员账号，系统将验证您的身份。</p>
                    <form id="step1Form">
                        <div class="mb-3">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="username" name="username" placeholder="管理员账号" required autofocus>
                                <label for="username">管理员账号</label>
                            </div>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary" id="step1Btn">
                                <i class="bi bi-arrow-right-circle me-1"></i>下一步
                            </button>
                        </div>
                    </form>
                    <div class="text-center mt-3">
                        <a href="/login" class="text-decoration-none small">
                            <i class="bi bi-arrow-left"></i> 返回登录
                        </a>
                    </div>
                </div>

                <!-- Step 2: 安全验证 + 设置新密码 -->
                <div class="step-panel" id="step2Panel">
                    <h5 class="card-title mb-3">设置新密码</h5>
                    <div class="security-hint">
                        <i class="bi bi-info-circle-fill me-1"></i>
                        安全验证问题：<strong>广电监控系统默认管理密码前三位字符是？</strong>
                    </div>
                    <form id="step2Form">
                        <input type="hidden" id="resetUsername">
                        <div class="mb-3">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="securityAnswer" name="security_answer" placeholder="安全问题答案" required>
                                <label for="securityAnswer">安全问题答案</label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="form-floating">
                                <input type="password" class="form-control" id="newPassword" name="new_password" placeholder="新密码" required minlength="6">
                                <label for="newPassword">新密码</label>
                            </div>
                            <div class="form-text">密码长度不少于6位</div>
                        </div>
                        <div class="mb-4">
                            <div class="form-floating">
                                <input type="password" class="form-control" id="confirmPassword" name="confirm_password" placeholder="确认新密码" required minlength="6">
                                <label for="confirmPassword">确认新密码</label>
                            </div>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary" id="step2Btn">
                                <i class="bi bi-check-circle me-1"></i>重置密码
                            </button>
                            <button type="button" class="btn btn-outline-secondary" id="backBtn">
                                <i class="bi bi-arrow-left"></i> 上一步
                            </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>

        <div class="text-center mt-4 text-muted">
            <small>&copy; <?php echo date('Y'); ?> 广播电视网络监控系统</small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    var currentStep = 1;
    var step1Form = document.getElementById('step1Form');
    var step2Form = document.getElementById('step2Form');
    var backBtn = document.getElementById('backBtn');
    var alertContainer = document.getElementById('alertContainer');

    function showAlert(message, type) {
        var wrapper = document.createElement('div');
        wrapper.className = 'alert alert-' + type + ' alert-dismissible fade show';
        wrapper.innerHTML =
            '<i class="bi bi-' + (type === 'danger' ? 'exclamation-triangle' : 'check-circle') + '-fill me-2"></i>' +
            message +
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        alertContainer.innerHTML = '';
        alertContainer.appendChild(wrapper);
    }

    function setStep(step) {
        currentStep = step;
        document.getElementById('step1Panel').classList.toggle('active', step === 1);
        document.getElementById('step2Panel').classList.toggle('active', step === 2);
        document.getElementById('stepDot1').className = 'step ' + (step === 1 ? 'active' : 'completed');
        document.getElementById('stepDot2').className = 'step ' + (step === 2 ? 'active' : '');
        document.getElementById('stepLine').className = 'step-line ' + (step === 2 ? 'active' : '');
        alertContainer.innerHTML = '';
    }

    step1Form.addEventListener('submit', function(e) {
        e.preventDefault();
        var username = document.getElementById('username').value.trim();
        if (!username) {
            showAlert('请输入管理员账号', 'danger');
            return;
        }
        document.getElementById('resetUsername').value = username;
        setStep(2);
    });

    backBtn.addEventListener('click', function() {
        setStep(1);
    });

    step2Form.addEventListener('submit', async function(e) {
        e.preventDefault();
        var submitBtn = document.getElementById('step2Btn');
        var answer = document.getElementById('securityAnswer').value.trim();
        var newPassword = document.getElementById('newPassword').value;
        var confirmPassword = document.getElementById('confirmPassword').value;

        if (!answer) {
            showAlert('请输入安全问题答案', 'danger');
            return;
        }
        if (newPassword.length < 6) {
            showAlert('密码长度不能少于6个字符', 'danger');
            return;
        }
        if (newPassword !== confirmPassword) {
            showAlert('两次输入的密码不一致', 'danger');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> 提交中...';

        try {
            var formData = new FormData();
            formData.append('username', document.getElementById('resetUsername').value);
            formData.append('new_password', newPassword);

            var response = await fetch('/auth/reset-password', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            var result = await response.json();

            if (result.success) {
                showAlert('密码重置成功，正在跳转登录页面...', 'success');
                setTimeout(function() {
                    window.location.href = '/login';
                }, 1500);
            } else {
                showAlert(result.message || result.error || '重置失败', 'danger');
            }
        } catch (error) {
            showAlert('请求出错：' + error.message, 'danger');
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i>重置密码';
        }
    });
    </script>
</body>
</html>
